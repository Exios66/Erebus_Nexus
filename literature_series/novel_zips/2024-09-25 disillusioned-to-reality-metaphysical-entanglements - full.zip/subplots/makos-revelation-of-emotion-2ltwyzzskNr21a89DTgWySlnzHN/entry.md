---
type: subplot
name: Mako’s Revelation of Emotion
color: null
aliases:
  - Mako’s
  - Revelation
  - Emotion
tags:
  - Subplot
  - Romance Plot
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
After a deeply influential discussion with Scarlet, Mako begins to experience hallucinations and false stimulations, hearing the echoes of Scarlet’s chaotic questions digging into her near android operating systems… Beginning to make her feel, emotion again? How strange…. For Scarlet. She begins to infatuate Mako as she is tasked with keeping tabs on Scarlet after she is redeployed to Earth after refusing Kaz’s request.