---
type: character
name: Professor Sebastian Grayson
color: gray
aliases:
  - Professor Sebastian Grayson
  - Sebastian
  - Grayson
tags:
  - Researcher
  - Incidental Character
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
\- Professor Sebastian Grayson, Chief Architect of Eidolon, Senior Researcher for Aegis and Kronos Corporations. Responsible for the initial inception and first thoughts of Eidolon.