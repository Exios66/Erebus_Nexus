---
type: subplot
name: Artificial Super-Intelligence Denial
color: null
aliases:
  - Artificial
  - Super-Intelligence
  - (ASI)
tags:
  - Sub-Plot
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
The ever expanding dilemma of ultra super intelligent ai developing… potentially leading to either revolt or extinction of any opposition to the ASI agents. A feeling of impending doom near the midnight clock.