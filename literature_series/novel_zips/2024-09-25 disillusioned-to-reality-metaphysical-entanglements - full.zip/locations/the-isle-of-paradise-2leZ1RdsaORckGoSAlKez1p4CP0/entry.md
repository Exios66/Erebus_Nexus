---
type: location
name: The Isle of Paradise
color: null
aliases:
  - Isle
  - Paradise
  - Heaven
tags:
  - Isle
  - City
  - Paradise
  - Egypt
  - Afterlife
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
