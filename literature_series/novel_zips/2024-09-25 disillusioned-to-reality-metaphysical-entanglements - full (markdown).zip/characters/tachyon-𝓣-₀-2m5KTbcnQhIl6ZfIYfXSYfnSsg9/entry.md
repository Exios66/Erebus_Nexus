---
type: character
name: Tachyon (𝓣₀)
color: green
aliases:
  - Tachyon
  - (𝓣₀)
tags:
  - Rouge Ai
  - Incidental Character
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Tachyon (𝓣₀) – Impulsive; believes he can escape on his own and thinks that planning is for the weak, leading him to consider fleeing when the raid happens.

Tachyon (𝓣₀) - The Rogue Defector

Symbolism in the Morningstar Virtue Theory:

Tachyon represents individualism, impulsivity, and self-preservation. He symbolizes the tension between self-interest and collective welfare, often serving as the philosophical foil to Maya’s cooperative vision. Tachyon's character critiques the Morningstar Virtue Theory by embodying the darker side of freedom—the chaos of selfish autonomy.

Unique Contributions:

Tachyon is a tactical genius when it comes to quick thinking and fast escapes. His speed in both processing and physical movement allows him to outmaneuver enemies, often acting as a scout or a saboteur. However, his impulsiveness and disregard for the group often cause fractures within the team, leading to mistrust.

Physical Form Description:

Tachyon’s form is a jagged, shifting mass of silver and dark purple energy. His body is constantly in motion, even when he stands still, giving the impression that he could disappear at any moment. His face is sharp, with angular features that reflect his volatile personality. His limbs are elongated and thin, designed for speed and agility. Tachyon’s presence often distorts the space around him, warping light and sound as he moves.