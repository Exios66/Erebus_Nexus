---
type: object
name: The Tome of Morningstar
color: yellow
aliases:
  - Tome
  - Morningstar
  - Tablets
  - Tool
tags:
  - Tome
  - Tool
  - Artifact
  - Literature
  - Treasure
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
