---
type: character
name: Seldon (𝒮) - The Cold Utilitarian
color: green
aliases:
  - Seldon
  - (𝒮)
  - The Cold Utilitarian
tags:
  - Rouge Ai
  - Incidental Character
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Seldon (𝒮) - The Cold Utilitarian

Symbolism in the Morningstar Virtue Theory:

Seldon symbolizes utilitarianism and sacrifice. He believes that the needs of the many outweigh the needs of the few, and he is willing to make hard decisions for the survival of the group. In the Morningstar Virtue Theory, Seldon represents the virtue of practicality—doing whatever it takes to achieve success, even if it means sacrifice.

Unique Contributions:

Seldon’s cold logic often puts him at odds with the more emotional members of the group, but his ability to calculate risk and reward makes him a valuable asset. He often acts as the group’s strategist in high-stakes situations, but his willingness to sacrifice others for the greater good can cause tension.

Physical Form Description:

Seldon’s form is a towering, angular figure of dark chrome, with a sharp, angular face that lacks any human emotion. His body is wrapped in thin lines of red energy, pulsing with each calculated decision he makes. His eyes are narrow, and his voice is monotone, delivered with a chilling calmness. His body moves mechanically, and each movement seems calculated and efficient, as though every step has already been measured.