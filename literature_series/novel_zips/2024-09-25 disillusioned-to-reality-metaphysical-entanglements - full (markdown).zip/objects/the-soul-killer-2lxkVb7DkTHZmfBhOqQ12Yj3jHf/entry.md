---
type: object
name: The SoulKiller
color: purple
aliases:
  - Soulkiller
tags:
  - Soulkiller
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
An exclusive quantum computing chip to upload your consciousness into in lieu of death to continue your journey in the body of another. Proud product of Kronos, Prometheus, and NeuroNet.