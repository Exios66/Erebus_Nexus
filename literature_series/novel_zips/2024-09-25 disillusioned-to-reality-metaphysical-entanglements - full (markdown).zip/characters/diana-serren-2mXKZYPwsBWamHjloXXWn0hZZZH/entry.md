---
type: character
name: Diana Serren
color: null
aliases:
  - Diana
  - Serren
tags:
  - CEO
  - DataDyne
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Diana Serren, the unassailable & Cutthroat CEO of DataDyne, who has been increasingly obsessive in her time spent within her virtual reality, to the point she has begun tipping into the questionable status of reality around her.