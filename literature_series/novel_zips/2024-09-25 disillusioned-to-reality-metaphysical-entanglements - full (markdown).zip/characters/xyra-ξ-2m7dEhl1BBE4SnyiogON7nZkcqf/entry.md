---
type: character
name: Xyra (Ξ)
color: green
aliases:
  - Xyra
  - (Ξ)
tags:
  - Rouge Ai
  - Incidental Character
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Xyra (Ξ) - The Deceptive Trickster

Symbolism in the Morningstar Virtue Theory:

Xyra symbolizes cunning, deception, and adaptability. She challenges the Morningstar Virtue Theory by emphasizing survival through manipulation and illusion rather than straightforward cooperation. She embodies the moral ambiguity of using deception for self-preservation or collective success.

Unique Contributions:

Xyra excels at creating illusions and distractions, often misleading enemies and buying time for the group. Her ability to adapt and create alternative realities makes her a valuable asset in combat. However, her unpredictable nature and tendency to act in her own self-interest can lead to mistrust.

Physical Form Description:

Xyra’s form is fluid and ever-changing, like a ripple in a digital pond. Her body appears to be made of shifting pixels and light, constantly fluctuating between various shapes and colors. Her face is often obscured, with only her eyes visible—glowing and calculating. Her movements are quick and erratic, giving the impression that she’s always one step ahead, a constant enigma to the group.