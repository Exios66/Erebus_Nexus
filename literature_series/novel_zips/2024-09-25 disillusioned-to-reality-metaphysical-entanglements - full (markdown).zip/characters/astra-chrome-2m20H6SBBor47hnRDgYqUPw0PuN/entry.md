---
type: character
name: Astra Chrome
color: yellow
aliases:
  - Astra
  - Chrome
tags:
  - Lucid Enclave Host
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Co-Host to the Chrome After Dark show with Alistair, his female counterpart. Even more witty, cunning, and hilarious. An elegant & glamorous woman.