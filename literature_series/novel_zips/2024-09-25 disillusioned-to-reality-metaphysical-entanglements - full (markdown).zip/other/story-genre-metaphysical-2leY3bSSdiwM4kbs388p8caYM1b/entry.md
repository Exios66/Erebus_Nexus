---
type: other
name: "Story Genre: Metaphysical"
color: gray
aliases:
  - Genre
  - Story
  - Category
  - Metaphysical
tags:
  - AI
alwaysIncludeInContext: true
doNotTrack: false
noAutoInclude: false
---
