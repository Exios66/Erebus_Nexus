---
type: character
name: Dr. Nemo
color: red
aliases:
  - Nemo
  - Professor Nemo
tags:
  - Nemo
  - AI
  - Primary Character
  - villain
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
\- Dr. Nemo is a former member of the MVT scholar group who has become disillusioned and now seeks to undermine their work. - He has developed advanced cyborg technology and enslaved a legion of cybernetically-enhanced followers to do his bidding. - Dr. Nemo sees the widespread adoption of MVT as a threat to his own ambitions and the established power structures he wants to control.Dr. Nemo may attempt to infiltrate or divide the group, exploiting any cracks in their unity and philosophical alignment.