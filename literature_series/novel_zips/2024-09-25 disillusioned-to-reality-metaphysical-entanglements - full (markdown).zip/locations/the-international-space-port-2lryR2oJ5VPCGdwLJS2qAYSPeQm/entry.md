---
type: location
name: The International Space Port
color: yellow
aliases:
  - International
  - Space Port
  - ISP
tags:
  - Location
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
International Space Port Accessible from the Olympus Sky Tier, and the train from the Machine Layer. Flights accessible cross continental, or to one of Kronos’s space ports in orbit.