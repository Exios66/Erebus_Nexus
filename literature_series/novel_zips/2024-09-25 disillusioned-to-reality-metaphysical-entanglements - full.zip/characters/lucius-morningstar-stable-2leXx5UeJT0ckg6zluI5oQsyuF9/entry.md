---
type: character
name: Lucius Morningstar {Stable}
color: pink
aliases:
  - Lucifer
  - Lucius
  - Morningstar
  - "{Stable}"
tags:
  - Incidental Character
  - "{Stable}"
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
The stable and controlled side of Lucius, Before he loses control of his chaos and becomes the ruler of hell and unbridled chaos with rage.