---
type: location
name: The 9 Layers of Hell
color: red
aliases:
  - Layers
  - Hell
  - 9 Layers
tags:
  - Allegory
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
