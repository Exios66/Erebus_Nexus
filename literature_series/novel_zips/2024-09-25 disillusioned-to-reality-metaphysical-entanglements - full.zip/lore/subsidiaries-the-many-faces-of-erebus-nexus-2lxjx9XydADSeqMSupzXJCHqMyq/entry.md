---
type: lore
name: "Subsidiaries: The Many Faces of Erebus Nexus"
color: null
aliases:
  - Subsidiaries
  - Many Faces
  - The Nexus
tags:
  - Erebus Nexus
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Though Erebus Nexus itself remains in the shadows, its presence is felt everywhere through its network of subsidiaries. These companies operate in every major sector of the galactic economy, from finance and biotech to media and military technology. Each subsidiary is designed to appear independent, with its own branding, leadership, and corporate structure.