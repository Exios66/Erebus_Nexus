---
type: character
name: Mako "Ironclad" Yara
color: pink
aliases:
  - Mako
  - '"Ironclad"'
  - Yara
  - Atom Smasher
  - Enforcer
tags:
  - Atom-Smasher
  - Enforcer
  - Main Character
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Key Character: Mako "Ironclad" Yara Role: A cybernetically enhanced soldier, Yara is a relentless enforcer whose body is more machine than flesh, a symbol of corporate power’s dominance over individuality. Plot Contribution:

Yara operates as Kaz Voss's enforcer, a living weapon whose sole purpose is to protect Kaz's belief in utilitarian efficiency. She is sent after Lucius and Scarlet when their actions threaten to destabilize the fragile balance of Erebus Nexus.

Lucius and Scarlet’s Rivalry with Yara: Yara’s role in enforcing Nexum's cold, utilitarian laws makes her a physical embodiment of the system’s ruthlessness. She forces Lucius to confront the costs of his defiance against the regime and Scarlet to face the reality that control through violence can never yield lasting power.

Character Arc:

Yara begins as a weapon devoid of humanity, but as the narrative progresses, she starts to question the ethics of her own enhancements. Is she a tool of the system or a person with agency?