---
type: character
name: Maximilian Tycho
color: null
aliases:
  - Maximillian
  - Tycho
  - Maximilian
tags:
  - CEO
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Maximilian Tycho\*\*

\- \*\*Personality\*\*: A larger-than-life industrialist, Tycho built his empire by terraforming planets and constructing cities on the harshest worlds. His motto is "Any world can be made to serve humanity," but his real interest lies in control—once a planet is terraformed, its inhabitants are entirely dependent on his infrastructure.