---
type: character
name: Seraphon Voss
color: null
aliases:
  - Seraphon Voss
  - Seraphon
tags:
  - CEO
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Personality\*\*: Coldly charismatic, Seraphon is feared even by her fellow architects. She believes in the Nexus’s absolute domination and is willing to sacrifice entire worlds to achieve that end. Her mind operates like a finely tuned machine, always ten steps ahead of any possible scenario. Known for her \*\*unflinching demeanor\*\* and \*\*inscrutable motives\*\*, Voss is never emotional, and his decision-making is ruthless and calculated.

\*\*Specialties\*\*: Strategic coordination, war-gaming, psychological manipulation.