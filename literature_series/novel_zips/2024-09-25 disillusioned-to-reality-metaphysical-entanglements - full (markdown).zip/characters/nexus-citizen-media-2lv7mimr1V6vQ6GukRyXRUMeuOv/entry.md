---
type: character
name: Nexus Citizen [Media]
color: gray
aliases:
  - Nexus
  - Citizen
  - "[Media]"
  - Average Joe
tags:
  - Omniscent
  - Unbiased
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
An unbiased citizen watching the 24/7 News Circuit, always on top of the latest developments, all of the time.