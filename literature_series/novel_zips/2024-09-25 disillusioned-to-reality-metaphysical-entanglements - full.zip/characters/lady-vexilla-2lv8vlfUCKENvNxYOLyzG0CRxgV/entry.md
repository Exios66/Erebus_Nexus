---
type: character
name: Lady Vexilla
color: purple
aliases:
  - Lady Vexilla
  - Succubus
  - Lady
  - Vexilla
tags:
  - CFO
  - Corporate Figure
  - Incidental Character
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
one of Kronos's corporate board members, the esteemed Lady Vexilla. Seductive MILF from KRONOS, deploys sexual deviant behavior to corrupt opponents with allure.