---
type: location
name: The Midcity (The Machine Layer)
color: null
aliases:
  - Midcity
  - Machine
tags:
  - Layer-Two
  - Setting
  - Environment
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
