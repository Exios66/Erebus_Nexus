---
type: subplot
name: The Fourth Corporate War
color: null
aliases:
  - Fourth
  - Corporate
  - War
tags:
  - SubPlot
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
