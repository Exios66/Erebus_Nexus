---
type: location
name: Kronos Orbital Research Fleet
color: null
aliases:
  - Kronos Orbital
  - Research
  - Fleet
  - Orbital
tags:
  - Space Fleet
  - Kronos
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Kronos Orbital Research Laboratory, positioned directly at the median between the earth and the moon. A prison masquerading as a sanctuary dedicated to scientific inquiry.