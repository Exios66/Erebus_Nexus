---
type: other
name: Chrome After Dark
color: purple
aliases:
  - Chrome After Dark
  - Chrome AD
tags:
  - Late Night Show
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Alistair's late night witty talkshow, hosted by the Lucid Enclave where he hosts regular guests, propagandists, and researchers to push whatever narrative of the day is selected by the higher up management of Erebus Nexus