---
type: location
name: The Sky Layer (Olympus Tier)
color: blue
aliases:
  - Sky
  - Olympus
  - Layer-One
tags:
  - Location
  - Setting
  - Tier
  - Hierarchy
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
