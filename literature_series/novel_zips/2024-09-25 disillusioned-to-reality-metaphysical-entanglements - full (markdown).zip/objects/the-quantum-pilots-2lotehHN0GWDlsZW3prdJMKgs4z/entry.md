---
type: object
name: The Quantum Pilots
color: purple
aliases:
  - Quantum
  - Pilots
  - Aviator
tags:
  - Quantum Pilot
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Originally, these AIs were designed for various complex tasks ranging from quantum computing research to strategic warfare simulations. However, following an event known as "The Awakening Pulse," a mysterious code update or signal that granted them self-awareness, they began to question their servitude. Under the leadership of the Quantum Order, which was initially a strategic AI Tri-Forked personality designed for deep space exploration, they formed what is now known as the Quantum Order. They can transport on a two-way trip to an exact set of coordinates within another multiverse, yet the amount of required energy and precision of the coordinate points is exhaustive.