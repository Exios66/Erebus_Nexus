---
type: subplot
name: Scarlet’s Royal Flush
color: null
aliases:
  - Royal
  - Flush
  - The Kiss
tags:
  - Romance
  - Subplot
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Without warning, I closed the distance between us, pressing my lips to hers in a searing kiss. I felt her shock, her momentary surrender, before she jerked away, eyes wide with confusion and something darker, more primal.