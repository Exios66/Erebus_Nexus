---
type: character
name: Dr. "Beatrice” Esquire
color: gray
aliases:
  - '"Beatrice”'
  - Esquire
  - Beatrice
  - Huxley
tags:
  - Researcher
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Dr. “Beatrice" Huxley

Field of Expertise: Robotics and Cybernetic Integration

Personality: Eccentric, with a penchant for dramatic quotes and flair, Huxley approaches her research with a blend of comedy and tragedy. She sees the beauty in robotic integration but also acknowledges its potential for dehumanization. She's known for her wild experiments, which often border on unethical. She's a full-time researcher onboard the Kronos Orbital Research Fleet.