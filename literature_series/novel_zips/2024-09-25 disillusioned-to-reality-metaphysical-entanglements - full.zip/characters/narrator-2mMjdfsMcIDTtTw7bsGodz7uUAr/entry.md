---
type: character
name: Narrator
color: null
aliases:
  - Narrator
tags:
  - Omniscent
  - Narrator
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Third-person omniscient narrator who conveys important information to the audience and reader.