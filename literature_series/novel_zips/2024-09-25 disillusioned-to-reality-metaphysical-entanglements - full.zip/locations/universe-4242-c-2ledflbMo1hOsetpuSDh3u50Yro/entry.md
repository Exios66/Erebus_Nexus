---
type: location
name: Universe 4242-C
color: blue
aliases:
  - Universe
  - 4242-C
tags:
  - Home-Universe
alwaysIncludeInContext: true
doNotTrack: false
noAutoInclude: false
---
The Current, Starting Universe that the Novel Originates within. For Reference in cases of multi-verse travel. Current Year: 2077