---
type: object
name: The Golden Ratio
color: yellow
aliases:
  - Phi
  - Golden
  - Ratio
tags:
  - Phi
  - Tool
  - Mathematics
  - Golden
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
