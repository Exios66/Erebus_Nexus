---
type: other
name: Styx Industrial (Infrastructure & Terraforming)
color: null
aliases:
  - Styx
  - Industrial
  - Infrastructure
  - Terraforming
tags:
  - Monopoly
  - Terraforming
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Styx Industrial (Infrastructure & Terraforming)

Function: Terraforming and space infrastructure. Styx builds the cities and colonies of the future but locks them into contracts that ensure dependency on its technologies for generations.

Hidden Role: Preparing colonies for future military or political domination.