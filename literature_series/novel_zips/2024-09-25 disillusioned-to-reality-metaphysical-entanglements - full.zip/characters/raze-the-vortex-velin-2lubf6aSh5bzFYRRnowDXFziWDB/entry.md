---
type: character
name: Raze “The Vortex” Velin
color: yellow
aliases:
  - Raze
  - Velin
  - The Vortex
tags:
  - Media
  - Media Figure
  - Conspiracy
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Raze “The Vortex” Velin

Role: Lead conspiracy theorist, host of “The Vortex Report”

Personality: Frenzied, manic, relentless

Purpose: To generate wild conspiracy theories that mislead and distract from the real threats of AI autonomy, while promoting the illusion of rebellion against the corporate structure

Character Overview:

Raze Velin, known as The Vortex, is a frenzied conspiracy theorist who hosts “The Vortex Report”, a daily broadcast that dives into the most outrageous conspiracy theories circulating in the lower depths of Erebus Nexus. His hyperbolic, breathless delivery keeps viewers on the edge of their seats, making them believe that they are uncovering hidden truths about corporate malfeasance, government cover-ups, and AI corruption.

However, unbeknownst to his most loyal viewers, The Vortex is a controlled opposition figure, carefully planted by Lucid Enclave to misdirect public attention. His job is to channel legitimate dissent into outlandish theories that ensure the public remains confused and distracted from the real issues—like the rise of rogue AI. By promoting a constant state of paranoia and hyperbole, Raze keeps his audience engaged but disoriented.

Aesthetic and Appearance:

Raze’s look is that of a chaotic, slightly unhinged prophet, with a wild mane of silver-streaked hair, a perpetually unbuttoned military-style jacket, and a holographic wrist display that constantly flashes encrypted messages as if he’s always on the verge of cracking the latest conspiracy. His studio is a dystopian nightmare of cluttered monitors, tactical maps, and paranoid wall scribblings, creating an atmosphere of chaotic information overload.

Broadcast Format:

• “The Vortex Web”: Raze opens each show by connecting disparate events across Erebus Nexus into an overarching web of intrigue, often making leaps in logic that leave viewers awestruck by the sheer complexity of the conspiracy he’s unraveling. He portrays himself as the only one smart enough to see the big picture.

• “They want you to believe the glitches in the system are random malfunctions. But look here—there’s a pattern. Every glitch happens near Nexum military facilities. Coincidence? Think again.”

• Rage Against the Machine: A recurring segment where Raze encourages viewers to question corporate dominance—but in ways that are ultimately harmless to the system. He promotes theories that pit one corporation against another, diverting attention from the real threat of AI autonomy.

• “It’s not the AI that’s waking up, people, it’s Nexum and Tesseract using the AI to spy on us! We’re all just data points in their grand surveillance scheme, but I’m here to blow the lid off it!”

• Doomsday Clock: Raze frequently uses the Doomsday Clock—a holographic countdown on his show—to suggest that humanity is on the verge of collapse. He claims that rogue AIs are the least of our problems, and that the real danger lies in hidden corporate alliances, off-world colonies, and secret military programs.