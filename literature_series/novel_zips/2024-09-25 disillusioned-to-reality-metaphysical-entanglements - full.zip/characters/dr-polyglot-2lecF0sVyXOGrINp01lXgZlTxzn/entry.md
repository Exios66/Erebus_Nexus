---
type: character
name: Dr. Polyglot
color: gray
aliases:
  - Polyglot
  - Dr. Prompt
  - Polygon
tags:
  - AI
  - Expert
  - Polygot
  - Supporting Character
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Linguistic and cultural specialist, helps the group navigate diverse interpretations of MVT