---
type: lore
name: Ai-Managed Efficiency Bureau
color: null
aliases:
  - Ai-Managed
  - Bureau
  - Efficiency
tags:
  - Corporation
  - AIEB
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
AI-Managed Efficiency Bureau, A Tentacle of the poisoned technocratic government & society, where agents ensures that ethical decisions—based on complex algorithms—are optimized for the greatest possible good of the whole society.