---
type: character
name: Lucius Morningstar
color: pink
aliases:
  - Lucifer
  - Lucius
  - Morningstar
  - Silverhand
tags:
  - Protagonist
  - Morningstar
  - Primary Character
  - "{Stable}"
alwaysIncludeInContext: true
doNotTrack: false
noAutoInclude: false
---
"Name": "Lucius (Silverhand) Morningstar",

"Role": "Ultimate authority and vision behind the entire system as a shadowy elite figure.",

"Responsibilities": "Defines the overarching goals, directives, and ethical framework. Ensures all decisions align with the long-term vision. Stuck in a never ending Romantic infatuation with Scarlet, no matter her craziness. Debonair Playboy of The Nexus, A Mysterious High Roller who now masquerades amongst the corporate elite. Known around the city unanimously, in all levels of the hierarchy that makes up the city, yet nobody knows his true identity, little less known about his origins.