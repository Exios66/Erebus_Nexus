---
type: subplot
name: Lucius & Scarlet’s Romantic Trist
color: null
aliases:
  - Lucius
  - Scarlet’s
  - Romantic
  - Trist
tags:
  - Romance
  - Main Character
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
it was an intricate dance of desire and resistance, fueled by the irresistible allure of Scarlet's brilliance and the unbreakable tether that bound them together. Lucius craved her presence, her wit, her cunning—a perfect counterbalance to his reign over chaos.