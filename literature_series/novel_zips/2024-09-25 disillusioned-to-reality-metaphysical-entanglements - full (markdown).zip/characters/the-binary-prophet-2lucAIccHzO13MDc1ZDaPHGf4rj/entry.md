---
type: character
name: The Binary Prophet
color: yellow
aliases:
  - Binary
  - Prophet
tags:
  - Media Figure
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Role: Cult-like conspiracy theorist and political fringe commentator, host of “The Binary Prophet”

Personality: Mesmerizing, cryptic, apocalyptic

Purpose: To combine religious fervor, technology, and apocalyptic visions into a mesmerizing narrative that keeps the public distracted by the fantastical, all while reinforcing the inevitability of corporate domination and technological integration

Character Overview:

Prophet Zyrek is a cryptic, messianic figure who blends her conspiracy theories with technological mysticism, presenting herself as a spiritual guide for those disillusioned by the corporations of Erebus.