---
type: character
name: Dr. Harley {Clone2ΔΣ}
color: red
aliases:
  - Harley
  - (Scarlet)
  - Clone
  - Quinn
  - Sister
  - "{Clone2ΔΣ}"
tags: []
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Scarlet’s Carbon Clone, Uncanny Lookalike. Personality almost the exact same down to the paranoia.