---
type: character
name: Dr. Wren
color: gray
aliases:
  - Wren
  - Professor Wren
tags:
  - Aegis Researcher
  - Senior Researcher
  - Incidental Character
alwaysIncludeInContext: false
doNotTrack: false
noAutoInclude: false
---
Dr. Marcus Wren, Senior Researcher, Aegis Defense Solutions, Key Researcher on Eidolon.